package com.example.fcm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FcmDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FcmDemoApplication.class, args);
	}

}
