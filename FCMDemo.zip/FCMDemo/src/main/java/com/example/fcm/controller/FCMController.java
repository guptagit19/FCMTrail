package com.example.fcm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.fcm.service.FCMService;

import com.google.firebase.messaging.FirebaseMessagingException;

@RestController
public class FCMController {

    @Autowired
    private FCMService fcmService;

    @PostMapping("/send-notification")
    public String sendNotification(@RequestParam String token, @RequestParam String title, @RequestParam String body) {
        try {
            fcmService.sendNotification(token, title, body);
            return "Notification sent successfully!";
        } catch (FirebaseMessagingException e) {
            e.printStackTrace();
            return "Failed to send notification: " + e.getMessage();
        }
    }
}

